var tl = gsap.timeline({scrollTrigger:{
    trigger:".one",
    start:"45% 50%",
    end:"150% 50%",
    scrub:true,
    // markers:true,
}})
tl.to(".one #big-lays",{
    top:"123%",
    left:"4%",
    width:"32%",
    rotate:0,
},'two')
tl.to(".one #chips1",{
    top:"145%",
    left:"30%",
},'two')
tl.to(".one #chips2",{
    top:"167%",
    left:"30%",
},'two')
tl.to(".one #chips3",{
    top:"167%",
    left:"2%",
},'two')
tl.to(".one #tomato2",{
    top:"144%",
    width:"5%",
    left:"92%",
},'two')
tl.to(".one #tomato1",{
    top:"137.5%",
    width:"4.6%",
    left:"59.9%",
},'two')

var tl2 = gsap.timeline({scrollTrigger:{
    trigger:".two",
    start:"50% 45%",
    end:"150% 50%",
    scrub:true,
}})
tl2.to(".one #big-lays",{
    top:"240%",
    left:"-4%",
},'one')
tl2.to("#bowl-images",{
    top:"110%",
    right:"-2%",
    width:"20%",
},'one')
tl2.to("#chips1",{
    top:"260%",
    left:"23%",
    width:"8%",
},'one')
tl2.to("#chips2",{
    top:"260%",
    left:"29%",
    width:"8%",
},'one')
tl2.to("#chips3",{
    top:"260%",
    left:"23%",
    width:"8%",
},'one')
var tl3 = gsap.timeline({scrollTrigger:{
    trigger:".three",
    start:"-10% 80%",
    end:"50% 50%",
    scrub:true,
}})
tl3.to(".one #big-lays",{
    top:"376%",
    left:"40%",
    width:"20%",
})
// var PinkLays = document.querySelector("#pink-lays")
// PinkLays.addEventListener("mouseover",function(){
//     PinkLays.style.width = "15%"
// })
// PinkLays.addEventListener("mouseout",function(){
//     PinkLays.style.width = "13%"
// })
// var OrangeLays = document.querySelector("#orange-lays")
// OrangeLays.addEventListener("mouseover",function(){
//     OrangeLays.style.width = "15%"
// })
// OrangeLays.addEventListener("mouseout",function(){
//     OrangeLays.style.width = "13%"
// })
